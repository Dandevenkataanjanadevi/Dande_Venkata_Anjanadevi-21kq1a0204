import pandas as pd
s=[]
l=[]
def add_student(name,roll_number,marks):
    student={
        'name':name,
        'roll_number':roll_number,
        'marks':marks,
        'total_marks':sum(marks)
    }
    s.append(student)
n=int(input())
for i in range(n):
    name=input("Enter Name:")
    roll_number=int(input("Enter roll number:" ))
    marks=list(map(int,input("Enter marks:").split()))
    add_student(name,roll_number,marks)
print('name\t\troll_number\t\tmarks\t\ttotal_marks')    
for i in range(n):
    print(s[i]['name']+'\t\t'+str(s[i]['roll_number'])+'\t\t'+str(s[i]['marks'])+'\t\t'+str(s[i]['total_marks']))
#df=pd.DataFrame(s)
#print(df)
print('number of student:',len(s))
student_highest_marks=max(s,key=lambda x:x['total_marks'])
print('\nstudent_highest_marks')
print('name:',student_highest_marks['name'])
print('roll_number:',student_highest_marks['roll_number'])
print('marks:',student_highest_marks['marks'])
print('total_marks:',student_highest_marks['total_marks'])
student_lowest_marks=min(s,key=lambda x:x['total_marks'])
print('\nstudent_lowest_marks')
print('name:',student_lowest_marks['name'])
print('roll_number:',student_lowest_marks['roll_number'])
print('marks:',student_lowest_marks['marks'])
print('total_marks:',student_lowest_marks['total_marks'])
for i in range(n):
    l.append(s[i]['marks'][2])
    l.sort()
print(l)
subject_wise_highest_marks = {}
for student in s:
    for idx, mark in enumerate(student['marks']):
        #print(idx,mark)
        if idx not in subject_wise_highest_marks or mark > subject_wise_highest_marks[idx]:
            subject_wise_highest_marks[idx] = mark
print('\nSubject_wise_highest_marks:')
for idx, highest_mark in subject_wise_highest_marks.items():
    print('Subject', idx+1, ':', highest_mark)
clg=input()
for i in range(n):
    if (s[i]['name'])==clg:
        print(s[i]['name'],s[i]['roll_number'],s[i]['marks'],s[i]['total_marks'])
sorted_name=sorted(s,key=lambda x:x['name'])
print('sorted_name:')
for s in sorted_name:
    print(s['name'])
    






    



