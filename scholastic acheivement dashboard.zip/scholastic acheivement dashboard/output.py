Python 3.10.11 (tags/v3.10.11:7d4cc5a, Apr  5 2023, 00:38:17) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

============ RESTART: C:\Users\anjan\OneDrive\Desktop\anjuproject.py ===========
20
Enter Name:anju
Enter roll number:201
Enter marks:10 20 30 40
Enter Name:subbu
Enter roll number:202
Enter marks:20 30 40 50
Enter Name:likki
Enter roll number:203
Enter marks:30 40 50 60
Enter Name:jaya
Enter roll number:204
Enter marks:40 50 60 70
Enter Name:bujji
Enter roll number:205
Enter marks:50 60 70 80
Enter Name:devi
Enter roll number:206
Enter marks:60 70 80 90
Enter Name:anjana
Enter roll number:207
Enter marks:70 80 90 30
Enter Name:hema
Enter roll number:208
Enter marks:23 45 67 43
Enter Name:jyothi
Enter roll number:209
Enter marks:21 34 25 68
Enter Name:pooji
Enter roll number:210
Enter marks:45 76 43 21
Enter Name:janu
Enter roll number:211
Enter marks:32 65 97 62
Enter Name:keerthi
Enter roll number:212
Enter marks:23 65 97 62
Enter Name:akki
Enter roll number:213
Enter marks:41 76 93 20
Enter Name:nani
Enter roll number:214
Enter marks:70 34 25 61
Enter Name:poori
Enter roll number:215
Enter marks:23 41 52 76
Enter Name:aru
Enter roll number:216
Enter marks:43 80 75 20
Enter Name:kanna
Enter roll number:217
Enter marks:23 12 56 78
Enter Name:padma
Enter roll number:218
Enter marks:23 41 56 80
Enter Name:navya
Enter roll number:219
Enter marks:20 40 59 38
Enter Name:divya
Enter roll number:220
Enter marks:12 34 52 67
name		roll_number		marks		total_marks
anju		201		[10, 20, 30, 40]		100
subbu		202		[20, 30, 40, 50]		140
likki		203		[30, 40, 50, 60]		180
jaya		204		[40, 50, 60, 70]		220
bujji		205		[50, 60, 70, 80]		260
devi		206		[60, 70, 80, 90]		300
anjana		207		[70, 80, 90, 30]		270
hema		208		[23, 45, 67, 43]		178
jyothi		209		[21, 34, 25, 68]		148
pooji		210		[45, 76, 43, 21]		185
janu		211		[32, 65, 97, 62]		256
keerthi		212		[23, 65, 97, 62]		247
akki		213		[41, 76, 93, 20]		230
nani		214		[70, 34, 25, 61]		190
poori		215		[23, 41, 52, 76]		192
aru		216		[43, 80, 75, 20]		218
kanna		217		[23, 12, 56, 78]		169
padma		218		[23, 41, 56, 80]		200
navya		219		[20, 40, 59, 38]		157
divya		220		[12, 34, 52, 67]		165
number of student: 20

student_highest_marks
name: devi
roll_number: 206
marks: [60, 70, 80, 90]
total_marks: 300

student_lowest_marks
name: anju
roll_number: 201
marks: [10, 20, 30, 40]
total_marks: 100
[25, 25, 30, 40, 43, 50, 52, 52, 56, 56, 59, 60, 67, 70, 75, 80, 90, 93, 97, 97]

Subject_wise_highest_marks:
Subject 1 : 70
Subject 2 : 80
Subject 3 : 97
Subject 4 : 90
kanna
kanna 217 [23, 12, 56, 78] 169
sorted_name:
akki
anjana
anju
aru
bujji
devi
divya
hema
janu
jaya
jyothi
kanna
keerthi
likki
nani
navya
padma
pooji
poori
subbu
